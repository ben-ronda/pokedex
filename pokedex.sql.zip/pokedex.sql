-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Mar 08, 2016 at 11:31 AM
-- Server version: 5.7.10
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pokedex`
--
CREATE DATABASE IF NOT EXISTS `pokedex` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `pokedex`;

-- --------------------------------------------------------

--
-- Table structure for table `pokemon`
--

CREATE TABLE `pokemon` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `height_feet` int(11) DEFAULT NULL,
  `height_inches` int(11) DEFAULT NULL,
  `weight` decimal(5,1) DEFAULT NULL,
  `dex_number` varchar(4) DEFAULT NULL,
  `img` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pokemon`
--

INSERT INTO `pokemon` (`id`, `name`, `height_feet`, `height_inches`, `weight`, `dex_number`, `img`) VALUES
(2, 'Bulbasaur', 2, 4, '15.2', '001', '/images/bulbasaur.png'),
(3, 'Ivysaur', 3, 3, '28.7', '002', NULL),
(4, 'Venusaur', 6, 7, '220.5', '003', '/images/venusaur.png'),
(5, 'Charmander', 2, 0, '18.7', '004', '/images/charmander.png'),
(6, 'Charmeleon', 3, 7, '41.9', '005', '/images/charmeleon.png'),
(7, 'Charizard', 5, 7, '199.5', '006', '/images/charizard.png'),
(8, 'Squirtle', 1, 8, '19.8', '007', '/images/squirtle.png'),
(9, 'Wartortle', 3, 3, '49.6', '008', '/images/wartortle.png'),
(10, 'Blastoise', 5, 3, '188.5', '009', '/images/blastoise.png'),
(11, 'Caterpie', 1, 0, '6.4', '010', '/images/caterpie.png'),
(12, 'Metapod', 2, 4, '21.8', '011', '/images/metapod.png'),
(13, 'Butterfree', 3, 7, '70.5', '012', '/images/butterfree.png'),
(14, 'Weedle', 1, 0, '7.1', '013', '/images/weedle.png'),
(15, 'Kakuna', 2, 0, '22.0', '014', NULL),
(16, 'Beedrill', 3, 3, '65.0', '015', '/images/beedrill.png'),
(17, 'Pidgey', 1, 0, '4.0', '016', '/images/pidgey.png'),
(18, 'Pidgeotto', 3, 7, '66.1', '017', '/images/pidgeotto.png'),
(19, 'Pidgeot', 4, 11, '87.1', '018', '/images/pidgeot.png'),
(20, 'Rattata', 1, 0, '7.7', '019', '/images/rattata.png'),
(21, 'Raticate', 2, 4, '40.8', '020', '/images/raticate.png'),
(22, 'Spearow', 1, 0, '4.4', '021', '/images/spearow.png'),
(23, 'Fearow', 3, 11, '83.8', '022', '/images/fearow.png'),
(24, 'Ekans', 6, 7, '15.2', '023', '/images/ekans.png'),
(25, 'Arbok', 11, 6, '143.3', '024', '/images/arbok.png'),
(26, 'Pikachu', 1, 4, '13.2', '025', '/images/pikachu.png'),
(27, 'Raichu', 2, 7, '66.1', '026', '/images/raichu.png'),
(28, 'Sandshrew', 2, 0, '26.5', '027', '/images/sandshrew.png'),
(29, 'Sandslash', 3, 3, '65.0', '028', '/images/sandslash.png'),
(30, 'Nidoran (female)', 1, 4, '15.4', '029', '/images/nidoran.png'),
(31, 'Nidorina', 2, 7, '44.1', '030', '/images/nidorina.png'),
(32, 'Nidoqueen', 4, 3, '132.3', '031', '/images/nidoqueen.png'),
(33, 'Nidoran (male)', 1, 8, '19.8', '032', '/images/nidoran_male.png'),
(34, 'Nidorino', 2, 11, '43.0', '033', '/images/nidorino.png'),
(35, 'Nidoking', 4, 7, '136.7', '034', '/images/nidoking.png'),
(36, 'Clefairy', 2, 0, '16.5', '035', '/images/clefairy.png'),
(37, 'Clefable', 4, 3, '88.2', '036', '/images/clefable.png'),
(38, 'Vulpix', 2, 0, '21.8', '037', '/images/vulpix.png'),
(39, 'Ninetales', 3, 7, '43.9', '038', '/images/ninetales.png'),
(40, 'Jigglypuff', 1, 8, '12.1', '039', NULL),
(41, 'Wigglytuff', 3, 3, '26.5', '040', '/images/wigglytuff.png'),
(42, 'Zubat', 2, 7, '16.5', '041', '/images/zubat.png'),
(43, 'Golbat', 5, 3, '121.3', '042', '/images/golbat.png'),
(44, 'Oddish', 1, 8, '11.9', '043', '/images/oddish.png'),
(45, 'Gloom', 2, 7, '19.0', '044', '/images/gloom.png'),
(46, 'Vileplume', 3, 11, '41.0', '045', '/images/vileplume.png'),
(47, 'Paras', 1, 0, '11.9', '046', '/images/paras.png'),
(48, 'Parasect', 3, 3, '65.0', '047', '/images/parasect.png'),
(49, 'Venonat', 3, 3, '66.1', '048', '/images/venonat.png'),
(50, 'Venomoth', 4, 11, '27.6', '049', '/images/venomoth.png'),
(51, 'Diglett', 0, 8, '1.8', '050', '/images/diglett.png'),
(52, 'Dugtrio', 2, 4, '73.4', '051', '/images/dugtrio.png'),
(53, 'Meowth', 1, 4, '9.3', '052', '/images/meowth.png'),
(54, 'Persian', 3, 3, '70.5', '053', '/images/persian.png'),
(55, 'Psyduck', 2, 7, '43.2', '054', '/images/psyduck.png'),
(56, 'Golduck', 5, 7, '168.9', '055', '/images/golduck.png'),
(57, 'Mankey', 1, 8, '61.7', '056', '/images/mankey.png'),
(58, 'Primeape', 3, 3, '70.5', '057', '/images/primeape.png'),
(59, 'Growlithe', 2, 4, '41.9', '058', '/images/growlithe.png'),
(60, 'Arcanine', 6, 3, '341.7', '059', '/images/arcanine.png'),
(61, 'Poliwag', 2, 0, '27.3', '060', '/images/poliwag.png'),
(62, 'Poliwhirl', 3, 3, '44.1', '061', '/images/poliwhirl.png'),
(63, 'Poliwrath', 4, 3, '119.0', '062', '/images/poliwrath.png'),
(64, 'Abra', 2, 11, '43.0', '063', '/images/abra.png'),
(65, 'Kadabra', 4, 3, '124.6', '064', NULL),
(66, 'Alakazam', 4, 11, '105.8', '065', '/images/alakazam.png'),
(67, 'Machop', 2, 7, '43.0', '066', NULL),
(68, 'Machoke', 2, 7, '155.4', '067', NULL),
(69, 'Machamp', 5, 3, '286.6', '068', NULL),
(70, 'Bellesprout', 2, 4, '8.8', '069', '/images/bellsprout.png'),
(71, 'Weepinbell', 3, 3, '14.1', '070', '/images/weepinbell.png'),
(72, 'Victreebel', 5, 7, '34.2', '071', '/images/victreebel.png'),
(73, 'Tentacool', 2, 11, '100.3', '072', '/images/tentacool.png'),
(74, 'Tentacruel', 5, 3, '121.3', '073', '/images/tentacruel.png'),
(75, 'Geodude', 1, 4, '44.1', '074', '/images/geodude.png'),
(76, 'Graveler', 3, 3, '231.5', '075', '/images/graveler.png'),
(77, 'Golem', 4, 7, '661.4', '076', '/images/golem.png'),
(78, 'Ponyta', 3, 3, '66.1', '077', '/images/ponyta.png'),
(79, 'Rapidash', 5, 7, '209.4', '078', '/images/rapidash.png'),
(80, 'Slowpoke', 3, 11, '79.4', '079', '/images/slowpoke.png'),
(81, 'Slowbro', 5, 3, '173.1', '080', '/images/slowbro.png'),
(82, 'Magnemite', 1, 0, '13.2', '081', NULL),
(83, 'Magneton', 3, 3, '132.3', '082', NULL),
(84, 'Farfetch''d', 2, 7, '33.1', '083', '/images/farfetch_d.png'),
(85, 'Doduo', 4, 7, '86.4', '084', '/images/doduo.png'),
(86, 'Dodrio', 5, 11, '187.8', '085', '/images/dodrio.png'),
(87, 'Seel', 3, 7, '198.4', '086', '/images/seel.png'),
(88, 'Dewgong', 5, 7, '264.6', '087', '/images/dewgong.png'),
(89, 'Grimer', 2, 11, '66.1', '088', '/images/grimer.png'),
(90, 'Muk', 3, 11, '66.1', '089', '/images/muk.png'),
(91, 'Shellder', 1, 0, '8.8', '090', '/images/shellder.png'),
(92, 'Cloyster', 4, 11, '292.1', '091', '/images/cloyster.png'),
(93, 'Gastly', 4, 3, '0.2', '092', '/images/gastly.png'),
(94, 'Haunter', 5, 3, '0.2', '093', '/images/haunter.png'),
(95, 'Gengar', 4, 11, '89.3', '094', '/images/gengar.png'),
(96, 'Onix', 28, 10, '463.0', '095', '/images/onix.png'),
(97, 'Drowzee', 3, 3, '71.4', '096', '/images/drowzee.png'),
(98, 'Hypno', 5, 3, '166.7', '097', NULL),
(99, 'Krabby', 1, 4, '14.3', '098', NULL),
(100, 'Kingler', 4, 3, '132.3', '099', NULL),
(101, 'Voltorb', 1, 8, '22.9', '100', '/images/voltorb.png'),
(102, 'Electrode', 3, 11, '146.8', '101', NULL),
(103, 'Exeggcute', 1, 4, '5.5', '102', NULL),
(104, 'Exeggutor', 6, 7, '264.6', '103', NULL),
(105, 'Cubone', 1, 4, '14.3', '104', NULL),
(106, 'Marowak', 3, 3, '99.2', '105', NULL),
(107, 'Hitmonlee', 4, 11, '109.8', '106', NULL),
(108, 'Hitmonchan', 4, 7, '110.7', '107', NULL),
(109, 'Lickitung', 3, 11, '144.4', '108', NULL),
(110, 'Koffing', 2, 0, '2.2', '109', NULL),
(111, 'Weezing', 3, 11, '20.9', '110', NULL),
(112, 'Rhyhorn', 3, 3, '253.5', '111', NULL),
(113, 'Rhydon', 6, 3, '264.6', '112', NULL),
(114, 'Chansey', 3, 7, '76.3', '113', NULL),
(115, 'Tangela', 3, 3, '77.2', '114', NULL),
(116, 'Kangaskhan', 7, 3, '176.4', '115', NULL),
(117, 'Horsea', 1, 4, '17.6', '116', NULL),
(118, 'Seadra', 3, 11, '55.1', '117', NULL),
(119, 'Goldeen', 2, 0, '33.1', '118', NULL),
(120, 'Seaking', 4, 3, '86.0', '119', NULL),
(121, 'Staryu', 2, 7, '76.1', '120', NULL),
(122, 'Starmie', 3, 7, '176.4', '121', NULL),
(123, 'Mr.Mime', 4, 3, '120.1', '122', NULL),
(124, 'Scyther', 4, 11, '123.5', '123', NULL),
(125, 'Jynx', 4, 7, '89.5', '124', NULL),
(126, 'Electabuzz', 3, 7, '66.1', '125', NULL),
(127, 'Magmar', 4, 3, '98.1', '126', NULL),
(128, 'Pinser', 4, 11, '121.3', '127', NULL),
(129, 'Tauros', 4, 7, '194.9', '128', NULL),
(130, 'Magikarp', 2, 11, '22.0', '129', NULL),
(131, 'Gyarados', 21, 4, '518.1', '130', NULL),
(132, 'Lapras', 8, 2, '485.0', '131', NULL),
(133, 'Ditto', 1, 0, '8.8', '132', NULL),
(134, 'Eevee', 1, 0, '14.3', '133', NULL),
(135, 'Vaporeon', 3, 3, '63.9', '134', NULL),
(136, 'Jolteon', 2, 7, '54.0', '135', NULL),
(137, 'Flareon', 2, 11, '55.1', '136', NULL),
(138, 'Porygon', 2, 7, '80.5', '137', NULL),
(139, 'Omanyte', 1, 4, '16.5', '138', NULL),
(140, 'Omastar', 3, 3, '77.2', '139', NULL),
(141, 'Kabuto', 1, 8, '25.4', '140', NULL),
(142, 'Kabutops', 4, 3, '89.3', '141', NULL),
(143, 'Aerodactyl', 5, 11, '130.1', '142', NULL),
(144, 'Articuno', 5, 7, '122.1', '144', NULL),
(145, 'Zapdos', 5, 3, '116.0', '145', NULL),
(146, 'Moltres', 6, 7, '132.3', '146', NULL),
(147, 'Dratini', 5, 11, '7.3', '147', NULL),
(148, 'Dragonair', 13, 1, '36.4', '148', NULL),
(149, 'Dragonite', 7, 3, '463.0', '149', NULL),
(150, 'Mewtwo', 6, 7, '269.0', '150', NULL),
(151, 'Mew', 1, 4, '8.8', '151', NULL),
(152, 'Snorlax', 6, 11, '1014.1', '143', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pokemon`
--
ALTER TABLE `pokemon`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
