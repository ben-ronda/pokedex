-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Mar 11, 2016 at 08:57 AM
-- Server version: 5.7.10
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pokedex`
--
CREATE DATABASE IF NOT EXISTS `pokedex` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `pokedex`;

-- --------------------------------------------------------

--
-- Table structure for table `pokemon`
--

CREATE TABLE `pokemon` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `height_feet` int(11) DEFAULT NULL,
  `height_inches` int(11) DEFAULT NULL,
  `weight` decimal(5,1) DEFAULT NULL,
  `dex_number` varchar(4) DEFAULT NULL,
  `img` text,
  `description` text,
  `parent_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pokemon`
--

INSERT INTO `pokemon` (`id`, `name`, `height_feet`, `height_inches`, `weight`, `dex_number`, `img`, `description`, `parent_id`) VALUES
(2, 'Bulbasaur', 2, 4, '15.2', '001', '/images/pokemon/bulbasaur.png', 'Bulbasaur can be seen napping in bright sunlight. There is a seed on its back. By soaking up the sun''s rays, the seed grows progressively larger.\r\n', 0),
(3, 'Ivysaur', 3, 3, '28.7', '002', '/images/pokemon/ivysaur.png', 'There is a bud on this Pokémon''s back. To support its weight, Ivysaur''s legs and trunk grow thick and strong. If it starts spending more time lying in the sunlight, it''s a sign that the bud will bloom into a large flower soon.\r\n', 2),
(4, 'Venusaur', 6, 7, '220.5', '003', '/images/pokemon/venusaur.png', 'There is a large flower on Venusaur''s back. The flower is said to take on vivid colors if it gets plenty of nutrition and sunlight. The flower''s aroma soothes the emotions of people.\r\n', 3),
(5, 'Charmander', 2, 0, '18.7', '004', '/images/pokemon/charmander.png', 'The flame that burns at the tip of its tail is an indication of its emotions. The flame wavers when Charmander is enjoying itself. If the Pokémon becomes enraged, the flame burns fiercely.\r\n', 0),
(6, 'Charmeleon', 3, 7, '41.9', '005', '/images/pokemon/charmeleon.png', 'Charmeleon mercilessly destroys its foes using its sharp claws. If it encounters a strong foe, it turns aggressive. In this excited state, the flame at the tip of its tail flares with a bluish white color.\r\n', 5),
(7, 'Charizard', 5, 7, '199.5', '006', '/images/pokemon/charizard.png', 'Charizard flies around the sky in search of powerful opponents. It breathes fire of such great heat that it melts anything. However, it never turns its fiery breath on any opponent weaker than itself.\r\n', 6),
(8, 'Squirtle', 1, 8, '19.8', '007', '/images/pokemon/squirtle.png', 'Squirtle''s shell is not merely used for protection. The shell''s rounded shape and the grooves on its surface help minimize resistance in water, enabling this Pokémon to swim at high speeds.\r\n', 0),
(9, 'Wartortle', 3, 3, '49.6', '008', '/images/pokemon/wartortle.png', 'Its tail is large and covered with a rich, thick fur. The tail becomes increasingly deeper in color as Wartortle ages. The scratches on its shell are evidence of this Pokémon''s toughness as a battler.\r\n', 8),
(10, 'Blastoise', 5, 3, '188.5', '009', '/images/pokemon/blastoise.png', 'Blastoise has water spouts that protrude from its shell. The water spouts are very accurate. They can shoot bullets of water with enough accuracy to strike empty cans from a distance of over 160 feet.\r\n', 9),
(11, 'Caterpie', 1, 0, '6.4', '010', '/images/pokemon/caterpie.png', 'Caterpie has a voracious appetite. It can devour leaves bigger than its body right before your eyes. From its antenna, this Pokémon releases a terrifically strong odor.\r\n', 0),
(12, 'Metapod', 2, 4, '21.8', '011', '/images/pokemon/metapod.png', 'The shell covering this Pokémon''s body is as hard as an iron slab. Metapod does not move very much. It stays still because it is preparing its soft innards for evolution inside the hard shell.\r\n', 11),
(13, 'Butterfree', 3, 7, '70.5', '012', '/images/pokemon/butterfree.png', 'Butterfree has a superior ability to search for delicious honey from flowers. It can even search out, extract, and carry honey from flowers that are blooming over six miles from its nest.\r\n', 12),
(14, 'Weedle', 1, 0, '7.1', '013', '/images/pokemon/weedle.png', 'Weedle has an extremely acute sense of smell. It is capable of distinguishing its favorite kinds of leaves from those it dislikes just by sniffing with its big red proboscis (nose).\r\n', 0),
(15, 'Kakuna', 2, 0, '22.0', '014', '/images/pokemon/kakuna.png', 'Kakuna remains virtually immobile as it clings to a tree. However, on the inside, it is extremely busy as it prepares for its coming evolution. This is evident from how hot the shell becomes to the touch.\r\n', 14),
(16, 'Beedrill', 3, 3, '65.0', '015', '/images/pokemon/beedrill.png', 'Beedrill is extremely territorial. No one should ever approach its nest—this is for their own safety. If angered, they will attack in a furious swarm.\r\n', 15),
(17, 'Pidgey', 1, 0, '4.0', '016', '/images/pokemon/pidgey.png', 'Pidgey has an extremely sharp sense of direction. It is capable of unerringly returning home to its nest, however far it may be removed from its familiar surroundings.\r\n', 0),
(18, 'Pidgeotto', 3, 7, '66.1', '017', '/images/pokemon/pidgeotto.png', 'Pidgeotto claims a large area as its own territory. This Pokémon flies around, patrolling its living space. If its territory is violated, it shows no mercy in thoroughly punishing the foe with its sharp claws.\r\n', 17),
(19, 'Pidgeot', 4, 11, '87.1', '018', '/images/pokemon/pidgeot.png', 'This Pokémon has a dazzling plumage of beautifully glossy feathers. Many Trainers are captivated by the striking beauty of the feathers on its head, compelling them to choose Pidgeot as their Pokémon.\r\n', 18),
(20, 'Rattata', 1, 0, '7.7', '019', '/images/pokemon/rattata.png', 'Rattata is cautious in the extreme. Even while it is asleep, it constantly listens by moving its ears around. It is not picky about where it lives—it will make its nest anywhere.\r\n', 0),
(21, 'Raticate', 2, 4, '40.8', '020', '/images/pokemon/raticate.png', 'Raticate''s sturdy fangs grow steadily. To keep them ground down, it gnaws on rocks and logs. It may even chew on the walls of houses.\r\n', 20),
(22, 'Spearow', 1, 0, '4.4', '021', '/images/pokemon/spearow.png', 'Spearow has a very loud cry that can be heard over half a mile away. If its high, keening cry is heard echoing all around, it is a sign that they are warning each other of danger.\r\n', 0),
(23, 'Fearow', 3, 11, '83.8', '022', '/images/pokemon/fearow.png', 'Fearow is recognized by its long neck and elongated beak. They are conveniently shaped for catching prey in soil or water. It deftly moves its long and skinny beak to pluck prey.\r\n', 22),
(24, 'Ekans', 6, 7, '15.2', '023', '/images/pokemon/ekans.png', 'Ekans curls itself up in a spiral while it rests. Assuming this position allows it to quickly respond to a threat from any direction with a glare from its upraised head.\r\n', 0),
(25, 'Arbok', 11, 6, '143.3', '024', '/images/pokemon/arbok.png', 'This Pokémon is terrifically strong in order to constrict things with its body. It can even flatten steel oil drums. Once Arbok wraps its body around its foe, escaping its crunching embrace is impossible.\r\n', 24),
(26, 'Pikachu', 1, 4, '13.2', '025', '/images/pokemon/pikachu.png', 'Whenever Pikachu comes across something new, it blasts it with a jolt of electricity. If you come across a blackened berry, it''s evidence that this Pokémon mistook the intensity of its charge.\r\n', 0),
(27, 'Raichu', 2, 7, '66.1', '026', '/images/pokemon/raichu.png', 'If the electrical sacs become excessively charged, Raichu plants its tail in the ground and discharges. Scorched patches of ground will be found near this Pokémon''s nest.\r\n', 26),
(28, 'Sandshrew', 2, 0, '26.5', '027', '/images/pokemon/sandshrew.png', 'Sandshrew''s body is configured to absorb water without waste, enabling it to survive in an arid desert. This Pokémon curls up to protect itself from its enemies.\r\n', 0),
(29, 'Sandslash', 3, 3, '65.0', '028', '/images/pokemon/sandslash.png', 'Sandslash''s body is covered by tough spikes, which are hardened sections of its hide. Once a year, the old spikes fall out, to be replaced with new spikes that grow out from beneath the old ones.\r\n', 28),
(30, 'Nidoran (female)', 1, 4, '15.4', '029', '/images/pokemon/nidoran.png', 'Nidoran? has barbs that secrete a powerful poison. They are thought to have developed as protection for this small-bodied Pokémon. When enraged, it releases a horrible toxin from its horn.\r\n', 0),
(31, 'Nidorina', 2, 7, '44.1', '030', '/images/pokemon/nidorina.png', 'When Nidorina are with their friends or family, they keep their barbs tucked away to prevent hurting each other. This Pokémon appears to become nervous if separated from the others.\r\n', 30),
(32, 'Nidoqueen', 4, 3, '132.3', '031', '/images/pokemon/nidoqueen.png', 'Nidoqueen''s body is encased in extremely hard scales. It is adept at sending foes flying with harsh tackles. This Pokémon is at its strongest when it is defending its young.\r\n', 31),
(33, 'Nidoran (male)', 1, 8, '19.8', '032', '/images/pokemon/nidoran_male.png', 'Nidoran? has developed muscles for moving its ears. Thanks to them, the ears can be freely moved in any direction. Even the slightest sound does not escape this Pokémon''s notice.\r\n', 0),
(34, 'Nidorino', 2, 11, '43.0', '033', '/images/pokemon/nidorino.png', 'Nidorino has a horn that is harder than a diamond. If it senses a hostile presence, all the barbs on its back bristle up at once, and it challenges the foe with all its might.\r\n', 33),
(35, 'Nidoking', 4, 7, '136.7', '034', '/images/pokemon/nidoking.png', 'Nidoking''s thick tail packs enormously destructive power. With one swing, it can topple a metal transmission tower. Once this Pokémon goes on a rampage, there is no stopping it.\r\n', 34),
(36, 'Clefairy', 2, 0, '16.5', '035', '/images/pokemon/clefairy.png', 'On every night of a full moon, groups of this Pokémon come out to play. When dawn arrives, the tired Clefairy return to their quiet mountain retreats and go to sleep nestled up against each other.\r\n', 0),
(37, 'Clefable', 4, 3, '88.2', '036', '/images/pokemon/clefable.png', 'Clefable moves by skipping lightly as if it were flying using its wings. Its bouncy step lets it even walk on water. It is known to take strolls on lakes on quiet, moonlit nights.\r\n', 36),
(38, 'Vulpix', 2, 0, '21.8', '037', '/images/pokemon/vulpix.png', 'At the time of its birth, Vulpix has one white tail. The tail separates into six if this Pokémon receives plenty of love from its Trainer. The six tails become magnificently curled.\r\n', 0),
(39, 'Ninetales', 3, 7, '43.9', '038', '/images/pokemon/ninetales.png', 'Ninetales casts a sinister light from its bright red eyes to gain total control over its foe''s mind. This Pokémon is said to live for a thousand years.\r\n', 38),
(40, 'Jigglypuff', 1, 8, '12.1', '039', '/images/pokemon/jigglypuff.png', 'Jigglypuff''s vocal cords can freely adjust the wavelength of its voice. This Pokémon uses this ability to sing at precisely the right wavelength to make its foes most drowsy.\r\n', 0),
(41, 'Wigglytuff', 3, 3, '26.5', '040', '/images/pokemon/wigglytuff.png', 'Wigglytuff has large, saucerlike eyes. The surfaces of its eyes are always covered with a thin layer of tears. If any dust gets in this Pokémon''s eyes, it is quickly washed away.\r\n', 40),
(42, 'Zubat', 2, 7, '16.5', '041', '/images/pokemon/zubat.png', 'Zubat remains quietly unmoving in a dark spot during the bright daylight hours. It does so because prolonged exposure to the sun causes its body to become slightly burned.\r\n', 0),
(43, 'Golbat', 5, 3, '121.3', '042', '/images/pokemon/golbat.png', 'Golbat loves to drink the blood of living things. It is particularly active in the pitch black of night. This Pokémon flits around in the night skies, seeking fresh blood.\r\n', 42),
(44, 'Oddish', 1, 8, '11.9', '043', '/images/pokemon/oddish.png', 'During the daytime, Oddish buries itself in soil to absorb nutrients from the ground using its entire body. The more fertile the soil, the glossier its leaves become.\r\n', 0),
(45, 'Gloom', 2, 7, '19.0', '044', '/images/pokemon/gloom.png', 'Gloom releases a foul fragrance from the pistil of its flower. When faced with danger, the stench worsens. If this Pokémon is feeling calm and secure, it does not release its usual stinky aroma.\r\n', 44),
(46, 'Vileplume', 3, 11, '41.0', '045', '/images/pokemon/vileplume.png', 'Vileplume''s toxic pollen triggers atrocious allergy attacks. That''s why it is advisable never to approach any attractive flowers in a jungle, however pretty they may be.\r\n', 45),
(47, 'Paras', 1, 0, '11.9', '046', '/images/pokemon/paras.png', 'Paras has parasitic mushrooms growing on its back called tochukaso. They grow large by drawing nutrients from this Bug Pokémon host. They are highly valued as a medicine for extending life.\r\n', 0),
(48, 'Parasect', 3, 3, '65.0', '047', '/images/pokemon/parasect.png', 'Parasect is known to infest large trees en masse and drain nutrients from the lower trunk and roots. When an infested tree dies, they move onto another tree all at once.\r\n', 47),
(49, 'Venonat', 3, 3, '66.1', '048', '/images/pokemon/venonat.png', 'Venonat is said to have evolved with a coat of thin, stiff hair that covers its entire body for protection. It possesses large eyes that never fail to spot even minuscule prey.\r\n', 0),
(50, 'Venomoth', 4, 11, '27.6', '049', '/images/pokemon/venomoth.png', 'Venomoth is nocturnal—it is a Pokémon that only becomes active at night. Its favorite prey are small insects that gather around streetlights, attracted by the light in the darkness.\r\n', 49),
(51, 'Diglett', 0, 8, '1.8', '050', '/images/pokemon/diglett.png', 'Diglett are raised in most farms. The reason is simple— wherever this Pokémon burrows, the soil is left perfectly tilled for planting crops. This soil is made ideal for growing delicious vegetables.\r\n', 0),
(52, 'Dugtrio', 2, 4, '73.4', '051', '/images/pokemon/dugtrio.png', 'Dugtrio are actually triplets that emerged from one body. As a result, each triplet thinks exactly like the other two triplets. They work cooperatively to burrow endlessly.\r\n', 51),
(53, 'Meowth', 1, 4, '9.3', '052', '/images/pokemon/meowth.png', 'Meowth withdraws its sharp claws into its paws to slinkily sneak about without making any incriminating footsteps. For some reason, this Pokémon loves shiny coins that glitter with light.\r\n', 0),
(54, 'Persian', 3, 3, '70.5', '053', '/images/pokemon/persian.png', 'Persian has six bold whiskers that give it a look of toughness. The whiskers sense air movements to determine what is in the Pokémon''s surrounding vicinity. It becomes docile if grabbed by the whiskers.\r\n', 53),
(55, 'Psyduck', 2, 7, '43.2', '054', '/images/pokemon/psyduck.png', 'Psyduck uses a mysterious power. When it does so, this Pokémon generates brain waves that are supposedly only seen in sleepers. This discovery spurred controversy among scholars.\r\n', 0),
(56, 'Golduck', 5, 7, '168.9', '055', '/images/pokemon/golduck.png', 'The webbed flippers on its forelegs and hind legs and the streamlined body of Golduck give it frightening speed. This Pokémon is definitely much faster than even the most athletic swimmer.\r\n', 56),
(57, 'Mankey', 1, 8, '61.7', '056', '/images/pokemon/mankey.png', 'When Mankey starts shaking and its nasal breathing turns rough, it''s a sure sign that it is becoming angry. However, because it goes into a towering rage almost instantly, it is impossible for anyone to flee its wrath.\r\n', 0),
(58, 'Primeape', 3, 3, '70.5', '057', '/images/pokemon/primeape.png', 'When Primeape becomes furious, its blood circulation is boosted. In turn, its muscles are made even stronger. However, it also becomes much less intelligent at the same time.\r\n', 57),
(59, 'Growlithe', 2, 4, '41.9', '058', '/images/pokemon/growlithe.png', 'Growlithe has a superb sense of smell. Once it smells anything, this Pokémon won''t forget the scent, no matter what. It uses its advanced olfactory sense to determine the emotions of other living things.\r\n', 0),
(60, 'Arcanine', 6, 3, '341.7', '059', '/images/pokemon/arcanine.png', 'Arcanine is known for its high speed. It is said to be capable of running over 6,200 miles in a single day and night. The fire that blazes wildly within this Pokémon''s body is its source of power.\r\n', 59),
(61, 'Poliwag', 2, 0, '27.3', '060', '/images/pokemon/poliwag.png', 'Poliwag has a very thin skin. It is possible to see the Pokémon''s spiral innards right through the skin. Despite its thinness, however, the skin is also very flexible. Even sharp fangs bounce right off it.\r\n', 0),
(62, 'Poliwhirl', 3, 3, '44.1', '061', '/images/pokemon/poliwhirl.png', 'The surface of Poliwhirl''s body is always wet and slick with a slimy fluid. Because of this slippery covering, it can easily slip and slide out of the clutches of any enemy in battle.\r\n', 61),
(63, 'Poliwrath', 4, 3, '119.0', '062', '/images/pokemon/poliwrath.png', 'Poliwrath''s highly developed, brawny muscles never grow fatigued, however much it exercises. It is so tirelessly strong, this Pokémon can swim back and forth across the ocean without effort.\r\n', 62),
(64, 'Abra', 2, 11, '43.0', '063', '/images/pokemon/abra.png', 'Abra sleeps for eighteen hours a day. However, it can sense the presence of foes even while it is sleeping. In such a situation, this Pokémon immediately teleports to safety.\r\n', 0),
(65, 'Kadabra', 4, 3, '124.6', '064', '/images/pokemon/kadabra.png', 'Kadabra emits a peculiar alpha wave if it develops a headache. Only those people with a particularly strong psyche can hope to become a Trainer of this Pokémon.\r\n', 64),
(66, 'Alakazam', 4, 11, '105.8', '065', '/images/pokemon/alakazam.png', 'Alakazam''s brain continually grows, making its head far too heavy to support with its neck. This Pokémon holds its head up using its psychokinetic power instead.\r\n', 65),
(67, 'Machop', 2, 7, '43.0', '066', '/images/pokemon/machop.png', 'Machop''s muscles are special—they never get sore no matter how much they are used in exercise. This Pokémon has sufficient power to hurl a hundred adult humans.\r\n', 0),
(68, 'Machoke', 2, 7, '155.4', '067', '/images/pokemon/machoke.png', 'Machoke''s thoroughly toned muscles possess the hardness of steel. This Pokémon has so much strength, it can easily hold aloft a sumo wrestler on just one finger.\r\n', 67),
(69, 'Machamp', 5, 3, '286.6', '068', '/images/pokemon/machamp.png', 'Machamp has the power to hurl anything aside. However, trying to do any work requiring care and dexterity causes its arms to get tangled. This Pokémon tends to leap into action before it thinks.\r\n', 68),
(70, 'Bellesprout', 2, 4, '8.8', '069', '/images/pokemon/bellsprout.png', 'Bellsprout''s thin and flexible body lets it bend and sway to avoid any attack, however strong it may be. From its mouth, this Pokémon spits a corrosive fluid that melts even iron.\r\n', 0),
(71, 'Weepinbell', 3, 3, '14.1', '070', '/images/pokemon/weepinbell.png', 'Weepinbell has a large hook on its rear end. At night, the Pokémon hooks on to a tree branch and goes to sleep. If it moves around in its sleep, it may wake up to find itself on the ground.\r\n', 70),
(72, 'Victreebel', 5, 7, '34.2', '071', '/images/pokemon/victreebel.png', 'Victreebel has a long vine that extends from its head. This vine is waved and flicked about as if it were an animal to attract prey. When an unsuspecting prey draws near, this Pokémon swallows it whole.\r\n', 71),
(73, 'Tentacool', 2, 11, '100.3', '072', '/images/pokemon/tentacool.png', 'Tentacool''s body is largely composed of water. If it is removed from the sea, it dries up like parchment. If this Pokémon happens to become dehydrated, put it back into the sea.\r\n', 0),
(74, 'Tentacruel', 5, 3, '121.3', '073', '/images/pokemon/tentacruel.png', 'Tentacruel has large red orbs on its head. The orbs glow before lashing the vicinity with a harsh ultrasonic blast. This Pokémon''s outburst creates rough waves around it.\r\n', 73),
(75, 'Geodude', 1, 4, '44.1', '074', '/images/pokemon/geodude.png', 'The longer a Geodude lives, the more its edges are chipped and worn away, making it more rounded in appearance. However, this Pokémon''s heart will remain hard, craggy, and rough always.\r\n', 0),
(76, 'Graveler', 3, 3, '231.5', '075', '/images/pokemon/graveler.png', 'Graveler grows by feeding on rocks. Apparently, it prefers to eat rocks that are covered in moss. This Pokémon eats its way through a ton of rocks on a daily basis.\r\n', 75),
(77, 'Golem', 4, 7, '661.4', '076', '/images/pokemon/golem.png', 'Golem live up on mountains. If there is a large earthquake, these Pokémon will come rolling down off the mountains en masse to the foothills below.\r\n', 76),
(78, 'Ponyta', 3, 3, '66.1', '077', '/images/pokemon/ponyta.png', 'Ponyta is very weak at birth. It can barely stand up. This Pokémon becomes stronger by stumbling and falling to keep up with its parent.\r\n', 0),
(79, 'Rapidash', 5, 7, '209.4', '078', '/images/pokemon/rapidash.png', 'Rapidash usually can be seen casually cantering in the fields and plains. However, when this Pokémon turns serious, its fiery manes flare and blaze as it gallops its way up to 150 mph.\r\n', 78),
(80, 'Slowpoke', 3, 11, '79.4', '079', '/images/pokemon/slowpoke.png', 'Slowpoke uses its tail to catch prey by dipping it in water at the side of a river. However, this Pokémon often forgets what it''s doing and often spends entire days just loafing at water''s edge.\r\n', 0),
(81, 'Slowbro', 5, 3, '173.1', '080', '/images/pokemon/slowbro.png', 'Slowbro''s tail has a Shellder firmly attached with a bite. As a result, the tail can''t be used for fishing anymore. This causes Slowbro to grudgingly swim and catch prey instead.\r\n', 80),
(82, 'Magnemite', 1, 0, '13.2', '081', '/images/pokemon/magnemite.png', 'Magnemite attaches itself to power lines to feed on electricity. If your house has a power outage, check your circuit breakers. You may find a large number of this Pokémon clinging to the breaker box.\r\n', 0),
(83, 'Magneton', 3, 3, '132.3', '082', '/images/pokemon/magneton.png', 'Magneton emits a powerful magnetic force that is fatal to mechanical devices. As a result, large cities sound sirens to warn citizens of large-scale outbreaks of this Pokémon.\r\n', 82),
(84, 'Farfetch''d', 2, 7, '33.1', '083', '/images/pokemon/farfetch_d.png', 'Farfetch''d is always seen with a stalk from a plant of some sort. Apparently, there are good stalks and bad stalks. This Pokémon has been known to fight with others over stalks.\r\n', 0),
(85, 'Doduo', 4, 7, '86.4', '084', '/images/pokemon/doduo.png', 'Doduo''s two heads never sleep at the same time. Its two heads take turns sleeping, so one head can always keep watch for enemies while the other one sleeps.\r\n', 0),
(86, 'Dodrio', 5, 11, '187.8', '085', '/images/pokemon/dodrio.png', 'Watch out if Dodrio''s three heads are looking in three separate directions. It''s a sure sign that it is on its guard. Don''t go near this Pokémon if it''s being wary—it may decide to peck you.\r\n', 85),
(87, 'Seel', 3, 7, '198.4', '086', '/images/pokemon/seel.png', 'Seel hunts for prey in the frigid sea underneath sheets of ice. When it needs to breathe, it punches a hole through the ice with the sharply protruding section of its head.\r\n', 0),
(88, 'Dewgong', 5, 7, '264.6', '087', '/images/pokemon/dewgong.png', 'Dewgong loves to snooze on bitterly cold ice. The sight of this Pokémon sleeping on a glacier was mistakenly thought to be a mermaid by a mariner long ago.\r\n', 87),
(89, 'Grimer', 2, 11, '66.1', '088', '/images/pokemon/grimer.png', 'Grimer''s sludgy and rubbery body can be forced through any opening, however small it may be. This Pokémon enters sewer pipes to drink filthy wastewater.\r\n', 0),
(90, 'Muk', 3, 11, '66.1', '089', '/images/pokemon/muk.png', 'From Muk''s body seeps a foul fluid that gives off a nose-bendingly horrible stench. Just one drop of this Pokémon''s body fluid can turn a pool stagnant and rancid.\r\n', 89),
(91, 'Shellder', 1, 0, '8.8', '090', '/images/pokemon/shellder.png', 'At night, this Pokémon uses its broad tongue to burrow a hole in the seafloor sand and then sleep in it. While it is sleeping, Shellder closes its shell, but leaves its tongue hanging out.\r\n', 0),
(92, 'Cloyster', 4, 11, '292.1', '091', '/images/pokemon/cloyster.png', 'Cloyster is capable of swimming in the sea. It does so by swallowing water, then jetting it out toward the rear. This Pokémon shoots spikes from its shell using the same system.\r\n', 91),
(93, 'Gastly', 4, 3, '0.2', '092', '/images/pokemon/gastly.png', 'Gastly is largely composed of gaseous matter. When exposed to a strong wind, the gaseous body quickly dwindles away. Groups of this Pokémon cluster under the eaves of houses to escape the ravages of wind.\r\n', 0),
(94, 'Haunter', 5, 3, '0.2', '093', '/images/pokemon/haunter.png', 'Haunter is a dangerous Pokémon. If one beckons you while floating in darkness, you must never approach it. This Pokémon will try to lick you with its tongue and steal your life away.\r\n', 93),
(95, 'Gengar', 4, 11, '89.3', '094', '/images/pokemon/gengar.png', 'Sometimes, on a dark night, your shadow thrown by a streetlight will suddenly and startlingly overtake you. It is actually a Gengar running past you, pretending to be your shadow.\r\n', 94),
(96, 'Onix', 28, 10, '463.0', '095', '/images/pokemon/onix.png', 'Onix has a magnet in its brain. It acts as a compass so that this Pokémon does not lose direction while it is tunneling. As it grows older, its body becomes increasingly rounder and smoother.\r\n', 0),
(97, 'Drowzee', 3, 3, '71.4', '096', '/images/pokemon/drowzee.png', 'If your nose becomes itchy while you are sleeping, it''s a sure sign that one of these Pokémon is standing above your pillow and trying to eat your dream through your nostrils.\r\n', 0),
(98, 'Hypno', 5, 3, '166.7', '097', '/images/pokemon/hypno.png', 'Hypno holds a pendulum in its hand. The arcing movement and glitter of the pendulum lull the foe into a deep state of hypnosis. While this Pokémon searches for prey, it polishes the pendulum.\r\n', 97),
(99, 'Krabby', 1, 4, '14.3', '098', '/images/pokemon/krabby.png', 'Krabby live on beaches, burrowed inside holes dug into the sand. On sandy beaches with little in the way of food, these Pokémon can be seen squabbling with each other over territory.\r\n', 0),
(100, 'Kingler', 4, 3, '132.3', '099', '/images/pokemon/kingler.png', 'Kingler has an enormous, oversized claw. It waves this huge claw in the air to communicate with others. However, because the claw is so heavy, the Pokémon quickly tires.\r\n', 99),
(101, 'Voltorb', 1, 8, '22.9', '100', '/images/pokemon/voltorb.png', 'Voltorb was first sighted at a company that manufactures Poké Balls. The link between that sighting and the fact that this Pokémon looks very similar to a Poké Ball remains a mystery.\r\n', 0),
(102, 'Electrode', 3, 11, '146.8', '101', '/images/pokemon/electrode.png', 'Electrode eats electricity in the atmosphere. On days when lightning strikes, you can see this Pokémon exploding all over the place from eating too much electricity.\r\n', 101),
(103, 'Exeggcute', 1, 4, '5.5', '102', '/images/pokemon/exeggcute.png', 'This Pokémon consists of six eggs that form a closely knit cluster. The six eggs attract each other and spin around. When cracks increasingly appear on the eggs, Exeggcute is close to evolution.\r\n\r\n', 0),
(104, 'Exeggutor', 6, 7, '264.6', '103', '/images/pokemon/exeggutor.png', 'Exeggutor originally came from the tropics. Its heads steadily grow larger from exposure to strong sunlight. It is said that when the heads fall off, they group together to form Exeggcute.\r\n', 103),
(105, 'Cubone', 1, 4, '14.3', '104', '/images/pokemon/cubone.png', 'Cubone pines for the mother it will never see again. Seeing a likeness of its mother in the full moon, it cries. The stains on the skull the Pokémon wears are made by the tears it sheds.\r\n', 104),
(106, 'Marowak', 3, 3, '99.2', '105', '/images/pokemon/marowak.png', 'Marowak is the evolved form of a Cubone that has overcome its sadness at the loss of its mother and grown tough. This Pokémon''s tempered and hardened spirit is not easily broken.\r\n', 105),
(107, 'Hitmonlee', 4, 11, '109.8', '106', '/images/pokemon/hitmonlee.png', 'Hitmonlee''s legs freely contract and stretch. Using these springlike legs, it bowls over foes with devastating kicks. After battle, it rubs down its legs and loosens the muscles to overcome fatigue.\r\n', 0),
(108, 'Hitmonchan', 4, 7, '110.7', '107', '/images/pokemon/hitmonchan.png', 'Hitmonchan is said to possess the spirit of a boxer who had been working toward a world championship. This Pokémon has an indomitable spirit and will never give up in the face of adversity.\r\n', 107),
(109, 'Lickitung', 3, 11, '144.4', '108', '/images/pokemon/lickitung.png', 'Whenever Lickitung comes across something new, it will unfailingly give it a lick. It does so because it memorizes things by texture and by taste. It is somewhat put off by sour things.\r\n', 0),
(110, 'Koffing', 2, 0, '2.2', '109', '/images/pokemon/koffing.png', 'If Koffing becomes agitated, it raises the toxicity of its internal gases and jets them out from all over its body. This Pokémon may also overinflate its round body, then explode.\r\n', 0),
(111, 'Weezing', 3, 11, '20.9', '110', '/images/pokemon/weezing.png', 'Weezing loves the gases given off by rotted kitchen garbage. This Pokémon will find a dirty, unkempt house and make it its home. At night, when the people in the house are asleep, it will go through the trash.\r\n', 110),
(112, 'Rhyhorn', 3, 3, '253.5', '111', '/images/pokemon/rhyhorn.png', 'Rhyhorn runs in a straight line, smashing everything in its path. It is not bothered even if it rushes headlong into a block of steel. This Pokémon may feel some pain from the collision the next day, however.\r\n', 0),
(113, 'Rhydon', 6, 3, '264.6', '112', '/images/pokemon/rhydon.png', 'Rhydon''s horn can crush even uncut diamonds. One sweeping blow of its tail can topple a building. This Pokémon''s hide is extremely tough. Even direct cannon hits don''t leave a scratch.\r\n', 112),
(114, 'Chansey', 3, 7, '76.3', '113', '/images/pokemon/chansey.png', 'Chansey lays nutritionally excellent eggs on an everyday basis. The eggs are so delicious, they are easily and eagerly devoured by even those people who have lost their appetite.\r\n', 0),
(115, 'Tangela', 3, 3, '77.2', '114', '/images/pokemon/tangela.png', 'Tangela''s vines snap off easily if they are grabbed. This happens without pain, allowing it to make a quick getaway. The lost vines are replaced by newly grown vines the very next day.\r\n', 0),
(116, 'Kangaskhan', 7, 3, '176.4', '115', '/images/pokemon/kangaskhan.png', 'If you come across a young Kangaskhan playing by itself, you must never disturb it or attempt to catch it. The baby Pokémon''s parent is sure to be in the area, and it will become violently enraged at you.\r\n', 0),
(117, 'Horsea', 1, 4, '17.6', '116', '/images/pokemon/horsea.png', 'Horsea eats small insects and moss off of rocks. If the ocean current turns fast, this Pokémon anchors itself by wrapping its tail around rocks or coral to prevent being washed away.\r\n', 0),
(118, 'Seadra', 3, 11, '55.1', '117', '/images/pokemon/seadra.png', 'Seadra sleeps after wriggling itself between the branches of coral. Those trying to harvest coral are occasionally stung by this Pokémon''s poison barbs if they fail to notice it.\r\n', 118),
(119, 'Goldeen', 2, 0, '33.1', '118', '/images/pokemon/goldeen.png', 'Goldeen is a very beautiful Pokémon with fins that billow elegantly in water. However, don''t let your guard down around this Pokémon—it could ram you powerfully with its horn.\r\n', 0),
(120, 'Seaking', 4, 3, '86.0', '119', '/images/pokemon/seaking.png', 'In the autumn, Seaking males can be seen performing courtship dances in riverbeds to woo females. During this season, this Pokémon''s body coloration is at its most beautiful.\r\n', 120),
(121, 'Staryu', 2, 7, '76.1', '120', '/images/pokemon/staryu.png', 'Staryu''s center section has an organ called the core that shines bright red. If you go to a beach toward the end of summer, the glowing cores of these Pokémon look like the stars in the sky.\r\n', 0),
(122, 'Starmie', 3, 7, '176.4', '121', '/images/pokemon/starmie.png', 'Starmie''s center section—the core—glows brightly in seven colors. Because of its luminous nature, this Pokémon has been given the nickname “the gem of the sea."\r\n', 121),
(123, 'Mr.Mime', 4, 3, '120.1', '122', '/images/pokemon/mr._mime.png', 'Mr. Mime is a master of pantomime. Its gestures and motions convince watchers that something unseeable actually exists. Once the watchers are convinced, the unseeable thing exists as if it were real.\r\n', 0),
(124, 'Scyther', 4, 11, '123.5', '123', '/images/pokemon/scyther.png', 'Scyther is blindingly fast. Its blazing speed enhances the effectiveness of the twin scythes on its forearms. This Pokémon''s scythes are so effective, they can slice through thick logs in one wicked stroke.\r\n', 0),
(125, 'Jynx', 4, 7, '89.5', '124', '/images/pokemon/jynx.png', 'Jynx walks rhythmically, swaying and shaking its hips as if it were dancing. Its motions are so bouncingly alluring, people seeing it are compelled to shake their hips without giving any thought to what they are doing.\r\n', 0),
(126, 'Electabuzz', 3, 7, '66.1', '125', '/images/pokemon/electabuzz.png', 'When a storm arrives, gangs of this Pokémon compete with each other to scale heights that are likely to be stricken by lightning bolts. Some towns use Electabuzz in place of lightning rods.\r\n', 0),
(127, 'Magmar', 4, 3, '98.1', '126', '/images/pokemon/magmar.png', 'In battle, Magmar blows out intensely hot flames from all over its body to intimidate its opponent. This Pokémon''s fiery bursts create heat waves that ignite grass and trees in its surroundings.\r\n', 0),
(128, 'Pinser', 4, 11, '121.3', '127', '/images/pokemon/pinser.png', 'Pinsir is astoundingly strong. It can grip a foe weighing twice its weight in its horns and easily lift it. This Pokémon''s movements turn sluggish in cold places.\r\n', 0),
(129, 'Tauros', 4, 7, '194.9', '128', '/images/pokemon/tauros.png', 'This Pokémon is not satisfied unless it is rampaging at all times. If there is no opponent for Tauros to battle, it will charge at thick trees and knock them down to calm itself.\r\n', 0),
(130, 'Magikarp', 2, 11, '22.0', '129', '/images/pokemon/magikarp.png', 'Magikarp is a pathetic excuse for a Pokémon that is only capable of flopping and splashing. This behavior prompted scientists to undertake research into it.\r\n', 0),
(131, 'Gyarados', 21, 4, '518.1', '130', '/images/pokemon/gyarados.png', 'When Magikarp evolves into Gyarados, its brain cells undergo a structural transformation. It is said that this transformation is to blame for this Pokémon''s wildly violent nature.\r\n', 130),
(132, 'Lapras', 8, 2, '485.0', '131', '/images/pokemon/lapras.png', 'People have driven Lapras almost to the point of extinction. In the evenings, this Pokémon is said to sing plaintively as it seeks what few others of its kind still remain.\r\n', 0),
(133, 'Ditto', 1, 0, '8.8', '132', '/images/pokemon/ditto.png', 'Ditto rearranges its cell structure to transform itself into other shapes. However, if it tries to transform itself into something by relying on its memory, this Pokémon manages to get details wrong.\r\n', 0),
(134, 'Eevee', 1, 0, '14.3', '133', '/images/pokemon/eevee.png', 'Eevee has an unstable genetic makeup that suddenly mutates due to the environment in which it lives. Radiation from various stones causes this Pokémon to evolve.\r\n', 0),
(135, 'Vaporeon', 3, 3, '63.9', '134', '/images/pokemon/vaporeon.png', 'Vaporeon underwent a spontaneous mutation and grew fins and gills that allow it to live underwater. This Pokémon has the ability to freely control water.\r\n', 134),
(136, 'Jolteon', 2, 7, '54.0', '135', '/images/pokemon/jolteon.png', 'Jolteon''s cells generate a low level of electricity. This power is amplified by the static electricity of its fur, enabling the Pokémon to drop thunderbolts. The bristling fur is made of electrically charged needles.\r\n', 134),
(137, 'Flareon', 2, 11, '55.1', '136', '/images/pokemon/flareon.png', 'Flareon''s fluffy fur has a functional purpose—it releases heat into the air so that its body does not get excessively hot. This Pokémon''s body temperature can rise to a maximum of 1,650 degrees Fahrenheit.\r\n', 134),
(138, 'Porygon', 2, 7, '80.5', '137', '/images/pokemon/porygon.png', 'Porygon is capable of reverting itself entirely back to program data and entering cyberspace. This Pokémon is copy protected so it cannot be duplicated by copying.\r\n', 0),
(139, 'Omanyte', 1, 4, '16.5', '138', '/images/pokemon/omanyte.png', 'Omanyte is one of the ancient and long-since-extinct Pokémon that have been regenerated from fossils by people. If attacked by an enemy, it withdraws itself inside its hard shell.\r\n', 0),
(140, 'Omastar', 3, 3, '77.2', '139', '/images/pokemon/omastar.png', 'Omastar uses its tentacles to capture its prey. It is believed to have become extinct because its shell grew too large and heavy, causing its movements to become too slow and ponderous.\r\n', 139),
(141, 'Kabuto', 1, 8, '25.4', '140', '/images/pokemon/kabuto.png', 'Kabuto is a Pokémon that has been regenerated from a fossil. However, in extremely rare cases, living examples have been discovered. The Pokémon has not changed at all for 300 million years.\r\n', 0),
(142, 'Kabutops', 4, 3, '89.3', '141', '/images/pokemon/kabutops.png', 'Kabutops swam underwater to hunt for its prey in ancient times. The Pokémon was apparently evolving from being a water dweller to living on land as evident from the beginnings of change in its gills and legs.\r\n', 141),
(143, 'Aerodactyl', 5, 11, '130.1', '142', '/images/pokemon/aerodactyl.png', 'Aerodactyl is a Pokémon from the age of dinosaurs. It was regenerated from genetic material extracted from amber. It is imagined to have been the king of the skies in ancient times.\r\n', 0),
(144, 'Articuno', 5, 7, '122.1', '144', '/images/pokemon/articuno.png', 'Articuno is a legendary bird Pokémon that can control ice. The flapping of its wings chills the air. As a result, it is said that when this Pokémon flies, snow will fall.\r\n', 0),
(145, 'Zapdos', 5, 3, '116.0', '145', '/images/pokemon/zapdos.png', 'Zapdos is a legendary bird Pokémon that has the ability to control electricity. It usually lives in thunderclouds. The Pokémon gains power if it is stricken by lightning bolts.\r\n', 0),
(146, 'Moltres', 6, 7, '132.3', '146', '/images/pokemon/moltres.png', 'Moltres is a legendary bird Pokémon that has the ability to control fire. If this Pokémon is injured, it is said to dip its body in the molten magma of a volcano to burn and heal itself.\r\n', 0),
(147, 'Dratini', 5, 11, '7.3', '147', '/images/pokemon/dratini.png', 'Dratini continually molts and sloughs off its old skin. It does so because the life energy within its body steadily builds to reach uncontrollable levels.\r\n', 0),
(148, 'Dragonair', 13, 1, '36.4', '148', '/images/pokemon/dragonair.png', 'Dragonair stores an enormous amount of energy inside its body. It is said to alter weather conditions in its vicinity by discharging energy from the crystals on its neck and tail.\r\n', 147),
(149, 'Dragonite', 7, 3, '463.0', '149', '/images/pokemon/dragonite.png', 'Dragonite is capable of circling the globe in just 16 hours. It is a kindhearted Pokémon that leads lost and foundering ships in a storm to the safety of land.\r\n', 148),
(150, 'Mewtwo', 6, 7, '269.0', '150', '/images/pokemon/mewtwo.png', 'Mewtwo is a Pokémon that was created by genetic manipulation. However, even though the scientific power of humans created this Pokémon''s body, they failed to endow Mewtwo with a compassionate heart.\r\n', 0),
(151, 'Mew', 1, 4, '8.8', '151', '/images/pokemon/mew.png', 'Mew is said to possess the genetic composition of all Pokémon. It is capable of making itself invisible at will, so it entirely avoids notice even if it approaches people.\r\n', 0),
(152, 'Snorlax', 6, 11, '1014.1', '143', '/images/pokemon/snorlax.png', 'Snorlax''s typical day consists of nothing more than eating and sleeping. It is such a docile Pokémon that there are children who use its expansive belly as a place to play.\r\n', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pokemon_types`
--

CREATE TABLE `pokemon_types` (
  `type_id` int(11) NOT NULL,
  `pokemon_id` int(11) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pokemon_types`
--

INSERT INTO `pokemon_types` (`type_id`, `pokemon_id`, `id`) VALUES
(9, 2, 1),
(13, 2, 2),
(9, 3, 3),
(13, 3, 4),
(9, 4, 5),
(13, 4, 6),
(6, 5, 7),
(6, 6, 8),
(6, 7, 9),
(7, 7, 10),
(17, 8, 11),
(17, 9, 12),
(17, 10, 13),
(1, 11, 14),
(1, 12, 15),
(1, 13, 16),
(7, 13, 17),
(1, 14, 18),
(13, 14, 19),
(1, 15, 20),
(13, 15, 21),
(1, 16, 22),
(13, 16, 23),
(7, 17, 24),
(12, 17, 25),
(7, 18, 26),
(12, 18, 27),
(7, 19, 28),
(12, 19, 29),
(12, 20, 30),
(12, 21, 31),
(12, 22, 32),
(7, 22, 33),
(7, 23, 34),
(12, 23, 35),
(13, 24, 36),
(13, 25, 37),
(4, 26, 38),
(4, 27, 39),
(10, 28, 40),
(10, 29, 41),
(13, 30, 42),
(13, 31, 43),
(13, 32, 44),
(10, 32, 45),
(13, 33, 46),
(13, 34, 47),
(13, 35, 48),
(10, 35, 49),
(12, 36, 50),
(12, 37, 51),
(6, 38, 52),
(6, 39, 53),
(12, 40, 54),
(12, 41, 55),
(7, 42, 56),
(13, 42, 57),
(7, 43, 58),
(13, 43, 59),
(13, 44, 60),
(9, 44, 61),
(13, 45, 62),
(9, 45, 63),
(13, 46, 64),
(9, 46, 65),
(1, 47, 66),
(9, 47, 67),
(1, 48, 68),
(9, 48, 69),
(1, 49, 70),
(13, 49, 71),
(13, 50, 72),
(1, 50, 73),
(4, 51, 74),
(4, 52, 75),
(12, 53, 76),
(12, 54, 77),
(17, 55, 78),
(17, 56, 79),
(5, 57, 80),
(5, 58, 81),
(6, 59, 82),
(6, 60, 83),
(17, 61, 84),
(17, 62, 85),
(17, 63, 86),
(5, 63, 87),
(14, 64, 88),
(14, 65, 89),
(14, 66, 90),
(5, 67, 91),
(5, 68, 92),
(5, 69, 93),
(9, 70, 94),
(13, 70, 95),
(9, 71, 96),
(13, 71, 97),
(9, 72, 98),
(13, 72, 99),
(17, 73, 100),
(13, 73, 101),
(13, 74, 102),
(17, 74, 103),
(10, 75, 104),
(15, 75, 105),
(10, 76, 106),
(15, 76, 107),
(10, 77, 108),
(15, 77, 109),
(6, 78, 110),
(6, 79, 111),
(14, 80, 112),
(17, 80, 113),
(14, 81, 114),
(17, 81, 115),
(4, 82, 116),
(4, 83, 117),
(7, 84, 118),
(12, 84, 119),
(7, 85, 120),
(12, 85, 121),
(7, 86, 122),
(12, 86, 123),
(17, 87, 124),
(17, 88, 125),
(11, 88, 126),
(13, 89, 127),
(13, 90, 128),
(17, 91, 129),
(17, 92, 130),
(11, 92, 131),
(8, 93, 132),
(13, 93, 133),
(8, 94, 134),
(13, 94, 135),
(8, 95, 136),
(13, 95, 137),
(15, 96, 138),
(10, 96, 139),
(14, 97, 140),
(14, 98, 141),
(17, 99, 142),
(17, 100, 143),
(4, 101, 144),
(4, 102, 145),
(9, 103, 146),
(14, 103, 147),
(9, 104, 148),
(14, 104, 149),
(4, 105, 150),
(4, 106, 151),
(5, 107, 152),
(5, 108, 153),
(12, 109, 154),
(13, 110, 155),
(13, 111, 156),
(10, 112, 157),
(15, 112, 158),
(10, 113, 159),
(15, 113, 160),
(12, 114, 161),
(9, 115, 162),
(12, 116, 163),
(17, 117, 164),
(17, 118, 165),
(17, 119, 166),
(17, 120, 167),
(17, 121, 168),
(14, 122, 169),
(17, 122, 170),
(14, 123, 171),
(1, 124, 172),
(7, 124, 173),
(11, 125, 174),
(14, 125, 175),
(4, 126, 176),
(6, 127, 177),
(1, 128, 178),
(12, 129, 179),
(17, 130, 180),
(17, 131, 181),
(7, 131, 182),
(11, 132, 183),
(17, 132, 184),
(12, 133, 185),
(12, 134, 186),
(17, 135, 187),
(4, 136, 188),
(6, 137, 189),
(12, 138, 190),
(15, 139, 191),
(17, 139, 192),
(17, 140, 193),
(15, 140, 194),
(15, 141, 195),
(17, 141, 196),
(15, 142, 197),
(17, 142, 198),
(15, 143, 199),
(7, 143, 200),
(7, 144, 201),
(11, 144, 202),
(12, 152, 203),
(7, 145, 205),
(4, 145, 206),
(7, 146, 207),
(6, 146, 208),
(3, 147, 209),
(3, 148, 210),
(3, 149, 211),
(7, 149, 212),
(14, 150, 213),
(14, 151, 214);

-- --------------------------------------------------------

--
-- Table structure for table `pokemon_users`
--

CREATE TABLE `pokemon_users` (
  `pokemon_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pokemon_users`
--

INSERT INTO `pokemon_users` (`pokemon_id`, `user_id`, `id`) VALUES
(2, 7, 5),
(7, 7, 6),
(24, 7, 8);

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `name` varchar(255) NOT NULL,
  `weakness` varchar(255) NOT NULL,
  `strength` varchar(255) NOT NULL,
  `img_path` varchar(100) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`name`, `weakness`, `strength`, `img_path`, `id`) VALUES
('Bug', 'Fire, Flying, Rock', 'Grass, Psychic', '/images/types/bug.png', 1),
('Dragon', 'Dragon, Ice', 'Dragon', '/images/types/dragon.png', 3),
('Electric', 'Ground', 'Flying, Water', '/images/types/electric.png', 4),
('Fighting', 'Flying, Psychic', ' Ice, Normal, Rock', '/images/types/fighting.png', 5),
('Fire', 'Ground, Rock, Water', 'Bug, Grass, Ice', '/images/types/fire.png', 6),
('Flying', 'Electric, Ice, Rock', 'Bug, Grass, Fighting', '/images/types/flying.png', 7),
('Ghost', 'Ghost', 'Ghost, Psychic', '/images/types/ghost.png', 8),
('Grass', 'Bug, Fire, Flying, Ice, Poison', 'Ground, Rock, Water', '/images/types/grass.png', 9),
('Ground', 'Grass, Ice, Water', 'Electric, Fire, Poison, Rock', '/images/types/ground.png', 10),
('Ice', 'Fighting, Fire, Rock, Steel', 'Dragon, Flying, Grass, Ground', '/images/types/ice.png', 11),
('Normal', 'Fighting', 'N/A', '/images/types/normal.png', 12),
('Poison', 'Ground, Psychic', 'Grass', '/images/types/poison.png', 13),
('Psychic', 'Bug,  Ghost', 'Fighting, Poison', '/images/types/psychic.png', 14),
('Rock', 'Fighting, Grass, Ground, Steel, Water', 'Bug, Fire, Flying, Ice', '/images/types/rock.png', 15),
('Water', 'Electric, Ground, Rock', 'Fire, Ground Rock', '/images/types/water.png', 17);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`username`, `password`, `id`) VALUES
('aaike001@gmail.com', 'tootsie', 5),
('bpopson@gmail.com', 'PASSWORD', 6),
('bronda95@comcast.net', '9dcf5hqk', 7),
('bpopson', 'password', 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `pokemon_types`
--
ALTER TABLE `pokemon_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pokemon_users`
--
ALTER TABLE `pokemon_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pokemon`
--
ALTER TABLE `pokemon`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT for table `pokemon_types`
--
ALTER TABLE `pokemon_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;
--
-- AUTO_INCREMENT for table `pokemon_users`
--
ALTER TABLE `pokemon_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
