--
-- Database: `pokedex`
--
CREATE DATABASE IF NOT EXISTS `pokedex` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `pokedex`;

-- --------------------------------------------------------

--
-- Table structure for table `pokemon`
--

CREATE TABLE `pokemon` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `height_feet` int(11) DEFAULT NULL,
  `height_inches` int(11) DEFAULT NULL,
  `weight` decimal(5,1) DEFAULT NULL,
  `dex_number` varchar(4) DEFAULT NULL,
  `img` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pokemon`
--

INSERT INTO `pokemon` (`id`, `name`, `height_feet`, `height_inches`, `weight`, `dex_number`, `img`) VALUES
(2, 'Bulbasaur', 2, 4, '15.2', '001', '/images/bulbasaur.png'),
(3, 'Ivysaur', 3, 3, '28.7', '002', '/images/ivysaur.png'),
(4, 'Venusaur', 6, 7, '220.5', '003', '/images/venusaur.png'),
(5, 'Charmander', 2, 0, '18.7', '004', '/images/charmander.png'),
(6, 'Charmeleon', 3, 7, '41.9', '005', '/images/charmeleon.png'),
(7, 'Charizard', 5, 7, '199.5', '006', '/images/charizard.png'),
(8, 'Squirtle', 1, 8, '19.8', '007', '/images/squirtle.png'),
(9, 'Wartortle', 3, 3, '49.6', '008', '/images/wartortle.png'),
(10, 'Blastoise', 5, 3, '188.5', '009', '/images/blastoise.png'),
(11, 'Caterpie', 1, 0, '6.4', '010', '/images/caterpie.png'),
(12, 'Metapod', 2, 4, '21.8', '011', '/images/metapod.png'),
(13, 'Butterfree', 3, 7, '70.5', '012', '/images/butterfree.png'),
(14, 'Weedle', 1, 0, '7.1', '013', '/images/weedle.png'),
(15, 'Kakuna', 2, 0, '22.0', '014', '/images/kakuna.png'),
(16, 'Beedrill', 3, 3, '65.0', '015', '/images/beedrill.png'),
(17, 'Pidgey', 1, 0, '4.0', '016', '/images/pidgey.png'),
(18, 'Pidgeotto', 3, 7, '66.1', '017', '/images/pidgeotto.png'),
(19, 'Pidgeot', 4, 11, '87.1', '018', '/images/pidgeot.png'),
(20, 'Rattata', 1, 0, '7.7', '019', '/images/rattata.png'),
(21, 'Raticate', 2, 4, '40.8', '020', '/images/raticate.png'),
(22, 'Spearow', 1, 0, '4.4', '021', '/images/spearow.png'),
(23, 'Fearow', 3, 11, '83.8', '022', '/images/fearow.png'),
(24, 'Ekans', 6, 7, '15.2', '023', '/images/ekans.png'),
(25, 'Arbok', 11, 6, '143.3', '024', '/images/arbok.png'),
(26, 'Pikachu', 1, 4, '13.2', '025', '/images/pikachu.png'),
(27, 'Raichu', 2, 7, '66.1', '026', '/images/raichu.png'),
(28, 'Sandshrew', 2, 0, '26.5', '027', '/images/sandshrew.png'),
(29, 'Sandslash', 3, 3, '65.0', '028', '/images/sandslash.png'),
(30, 'Nidoran (female)', 1, 4, '15.4', '029', '/images/nidoran.png'),
(31, 'Nidorina', 2, 7, '44.1', '030', '/images/nidorina.png'),
(32, 'Nidoqueen', 4, 3, '132.3', '031', '/images/nidoqueen.png'),
(33, 'Nidoran (male)', 1, 8, '19.8', '032', '/images/nidoran_male.png'),
(34, 'Nidorino', 2, 11, '43.0', '033', '/images/nidorino.png'),
(35, 'Nidoking', 4, 7, '136.7', '034', '/images/nidoking.png'),
(36, 'Clefairy', 2, 0, '16.5', '035', '/images/clefairy.png'),
(37, 'Clefable', 4, 3, '88.2', '036', '/images/clefable.png'),
(38, 'Vulpix', 2, 0, '21.8', '037', '/images/vulpix.png'),
(39, 'Ninetales', 3, 7, '43.9', '038', '/images/ninetales.png'),
(40, 'Jigglypuff', 1, 8, '12.1', '039', '/images/jigglypuff.png'),
(41, 'Wigglytuff', 3, 3, '26.5', '040', '/images/wigglytuff.png'),
(42, 'Zubat', 2, 7, '16.5', '041', '/images/zubat.png'),
(43, 'Golbat', 5, 3, '121.3', '042', '/images/golbat.png'),
(44, 'Oddish', 1, 8, '11.9', '043', '/images/oddish.png'),
(45, 'Gloom', 2, 7, '19.0', '044', '/images/gloom.png'),
(46, 'Vileplume', 3, 11, '41.0', '045', '/images/vileplume.png'),
(47, 'Paras', 1, 0, '11.9', '046', '/images/paras.png'),
(48, 'Parasect', 3, 3, '65.0', '047', '/images/parasect.png'),
(49, 'Venonat', 3, 3, '66.1', '048', '/images/venonat.png'),
(50, 'Venomoth', 4, 11, '27.6', '049', '/images/venomoth.png'),
(51, 'Diglett', 0, 8, '1.8', '050', '/images/diglett.png'),
(52, 'Dugtrio', 2, 4, '73.4', '051', '/images/dugtrio.png'),
(53, 'Meowth', 1, 4, '9.3', '052', '/images/meowth.png'),
(54, 'Persian', 3, 3, '70.5', '053', '/images/persian.png'),
(55, 'Psyduck', 2, 7, '43.2', '054', '/images/psyduck.png'),
(56, 'Golduck', 5, 7, '168.9', '055', '/images/golduck.png'),
(57, 'Mankey', 1, 8, '61.7', '056', '/images/mankey.png'),
(58, 'Primeape', 3, 3, '70.5', '057', '/images/primeape.png'),
(59, 'Growlithe', 2, 4, '41.9', '058', '/images/growlithe.png'),
(60, 'Arcanine', 6, 3, '341.7', '059', '/images/arcanine.png'),
(61, 'Poliwag', 2, 0, '27.3', '060', '/images/poliwag.png'),
(62, 'Poliwhirl', 3, 3, '44.1', '061', '/images/poliwhirl.png'),
(63, 'Poliwrath', 4, 3, '119.0', '062', '/images/poliwrath.png'),
(64, 'Abra', 2, 11, '43.0', '063', '/images/abra.png'),
(65, 'Kadabra', 4, 3, '124.6', '064', '/images/kadabra.png'),
(66, 'Alakazam', 4, 11, '105.8', '065', '/images/alakazam.png'),
(67, 'Machop', 2, 7, '43.0', '066', '/images/machop.png'),
(68, 'Machoke', 2, 7, '155.4', '067', '/images/machoke.png'),
(69, 'Machamp', 5, 3, '286.6', '068', '/images/machamp.png'),
(70, 'Bellesprout', 2, 4, '8.8', '069', '/images/bellsprout.png'),
(71, 'Weepinbell', 3, 3, '14.1', '070', '/images/weepinbell.png'),
(72, 'Victreebel', 5, 7, '34.2', '071', '/images/victreebel.png'),
(73, 'Tentacool', 2, 11, '100.3', '072', '/images/tentacool.png'),
(74, 'Tentacruel', 5, 3, '121.3', '073', '/images/tentacruel.png'),
(75, 'Geodude', 1, 4, '44.1', '074', '/images/geodude.png'),
(76, 'Graveler', 3, 3, '231.5', '075', '/images/graveler.png'),
(77, 'Golem', 4, 7, '661.4', '076', '/images/golem.png'),
(78, 'Ponyta', 3, 3, '66.1', '077', '/images/ponyta.png'),
(79, 'Rapidash', 5, 7, '209.4', '078', '/images/rapidash.png'),
(80, 'Slowpoke', 3, 11, '79.4', '079', '/images/slowpoke.png'),
(81, 'Slowbro', 5, 3, '173.1', '080', '/images/slowbro.png'),
(82, 'Magnemite', 1, 0, '13.2', '081', '/images/magnemite.png'),
(83, 'Magneton', 3, 3, '132.3', '082', '/images/magneton.png'),
(84, 'Farfetch''d', 2, 7, '33.1', '083', '/images/farfetch_d.png'),
(85, 'Doduo', 4, 7, '86.4', '084', '/images/doduo.png'),
(86, 'Dodrio', 5, 11, '187.8', '085', '/images/dodrio.png'),
(87, 'Seel', 3, 7, '198.4', '086', '/images/seel.png'),
(88, 'Dewgong', 5, 7, '264.6', '087', '/images/dewgong.png'),
(89, 'Grimer', 2, 11, '66.1', '088', '/images/grimer.png'),
(90, 'Muk', 3, 11, '66.1', '089', '/images/muk.png'),
(91, 'Shellder', 1, 0, '8.8', '090', '/images/shellder.png'),
(92, 'Cloyster', 4, 11, '292.1', '091', '/images/cloyster.png'),
(93, 'Gastly', 4, 3, '0.2', '092', '/images/gastly.png'),
(94, 'Haunter', 5, 3, '0.2', '093', '/images/haunter.png'),
(95, 'Gengar', 4, 11, '89.3', '094', '/images/gengar.png'),
(96, 'Onix', 28, 10, '463.0', '095', '/images/onix.png'),
(97, 'Drowzee', 3, 3, '71.4', '096', '/images/drowzee.png'),
(98, 'Hypno', 5, 3, '166.7', '097', '/images/hypno.png'),
(99, 'Krabby', 1, 4, '14.3', '098', '/images/krabby.png'),
(100, 'Kingler', 4, 3, '132.3', '099', '/images/kingler.png'),
(101, 'Voltorb', 1, 8, '22.9', '100', '/images/voltorb.png'),
(102, 'Electrode', 3, 11, '146.8', '101', '/images/electrode.png'),
(103, 'Exeggcute', 1, 4, '5.5', '102', '/images/exeggcute.png'),
(104, 'Exeggutor', 6, 7, '264.6', '103', '/images/exeggutor.png'),
(105, 'Cubone', 1, 4, '14.3', '104', '/images/cubone.png'),
(106, 'Marowak', 3, 3, '99.2', '105', '/images/marowak.png'),
(107, 'Hitmonlee', 4, 11, '109.8', '106', '/images/hitmonlee.png'),
(108, 'Hitmonchan', 4, 7, '110.7', '107', '/images/hitmonchan.png'),
(109, 'Lickitung', 3, 11, '144.4', '108', '/images/lickitung.png'),
(110, 'Koffing', 2, 0, '2.2', '109', '/images/koffing.png'),
(111, 'Weezing', 3, 11, '20.9', '110', '/images/weezing.png'),
(112, 'Rhyhorn', 3, 3, '253.5', '111', '/images/rhyhorn.png'),
(113, 'Rhydon', 6, 3, '264.6', '112', '/images/rhydon.png'),
(114, 'Chansey', 3, 7, '76.3', '113', '/images/chansey.png'),
(115, 'Tangela', 3, 3, '77.2', '114', '/images/tangela.png'),
(116, 'Kangaskhan', 7, 3, '176.4', '115', '/images/kangaskhan.png'),
(117, 'Horsea', 1, 4, '17.6', '116', '/images/horsea.png'),
(118, 'Seadra', 3, 11, '55.1', '117', '/images/seadra.png'),
(119, 'Goldeen', 2, 0, '33.1', '118', '/images/goldeen.png'),
(120, 'Seaking', 4, 3, '86.0', '119', '/images/seaking.png'),
(121, 'Staryu', 2, 7, '76.1', '120', '/images/staryu.png'),
(122, 'Starmie', 3, 7, '176.4', '121', '/images/starmie.png'),
(123, 'Mr.Mime', 4, 3, '120.1', '122', '/images/mr._mime.png'),
(124, 'Scyther', 4, 11, '123.5', '123', '/images/scyther.png'),
(125, 'Jynx', 4, 7, '89.5', '124', '/images/jynx.png'),
(126, 'Electabuzz', 3, 7, '66.1', '125', '/images/electabuzz.png'),
(127, 'Magmar', 4, 3, '98.1', '126', '/images/magmar.png'),
(128, 'Pinser', 4, 11, '121.3', '127', '/images/pinser.png'),
(129, 'Tauros', 4, 7, '194.9', '128', '/images/tauros.png'),
(130, 'Magikarp', 2, 11, '22.0', '129', '/images/magikarp.png'),
(131, 'Gyarados', 21, 4, '518.1', '130', '/images/gyarados.png'),
(132, 'Lapras', 8, 2, '485.0', '131', '/images/lapras.png'),
(133, 'Ditto', 1, 0, '8.8', '132', '/images/ditto.png'),
(134, 'Eevee', 1, 0, '14.3', '133', '/images/eevee.png'),
(135, 'Vaporeon', 3, 3, '63.9', '134', '/images/vaporeon.png'),
(136, 'Jolteon', 2, 7, '54.0', '135', '/images/jolteon.png'),
(137, 'Flareon', 2, 11, '55.1', '136', '/images/flareon.png'),
(138, 'Porygon', 2, 7, '80.5', '137', '/images/porygon.png'),
(139, 'Omanyte', 1, 4, '16.5', '138', '/images/omanyte.png'),
(140, 'Omastar', 3, 3, '77.2', '139', '/images/omastar.png'),
(141, 'Kabuto', 1, 8, '25.4', '140', '/images/kabuto.png'),
(142, 'Kabutops', 4, 3, '89.3', '141', '/images/kabutops.png'),
(143, 'Aerodactyl', 5, 11, '130.1', '142', '/images/aerodactyl.png'),
(144, 'Articuno', 5, 7, '122.1', '144', '/images/articuno.png'),
(145, 'Zapdos', 5, 3, '116.0', '145', '/images/zapdos.png'),
(146, 'Moltres', 6, 7, '132.3', '146', '/images/moltres.png'),
(147, 'Dratini', 5, 11, '7.3', '147', '/images/dratini.png'),
(148, 'Dragonair', 13, 1, '36.4', '148', '/images/dragonair.png'),
(149, 'Dragonite', 7, 3, '463.0', '149', '/images/dragonite.png'),
(150, 'Mewtwo', 6, 7, '269.0', '150', '/images/mewtwo.png'),
(151, 'Mew', 1, 4, '8.8', '151', '/images/mew.png'),
(152, 'Snorlax', 6, 11, '1014.1', '143', '/images/snorlax.png');

-- --------------------------------------------------------

--
-- Table structure for table `pokemon_types`
--

CREATE TABLE `pokemon_types` (
  `type_id` int(11) NOT NULL,
  `pokemon_id` int(11) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pokemon_types`
--

INSERT INTO `pokemon_types` (`type_id`, `pokemon_id`, `id`) VALUES
(9, 2, 1),
(13, 2, 2),
(9, 3, 3),
(13, 3, 4),
(9, 4, 5),
(13, 4, 6),
(6, 5, 7),
(6, 6, 8),
(6, 7, 9),
(7, 7, 10),
(17, 8, 11),
(17, 9, 12),
(17, 10, 13),
(1, 11, 14),
(1, 12, 15),
(1, 13, 16),
(7, 13, 17),
(1, 14, 18),
(13, 14, 19),
(1, 15, 20),
(13, 15, 21),
(1, 16, 22),
(13, 16, 23),
(7, 17, 24),
(12, 17, 25),
(7, 18, 26),
(12, 18, 27),
(7, 19, 28),
(12, 19, 29),
(12, 20, 30),
(12, 21, 31),
(12, 22, 32),
(7, 22, 33),
(7, 23, 34),
(12, 23, 35),
(13, 24, 36),
(13, 25, 37),
(4, 26, 38),
(4, 27, 39),
(10, 28, 40),
(10, 29, 41),
(13, 30, 42),
(13, 31, 43),
(13, 32, 44),
(10, 32, 45),
(13, 33, 46),
(13, 34, 47),
(13, 35, 48),
(10, 35, 49),
(12, 36, 50),
(12, 37, 51),
(6, 38, 52),
(6, 39, 53),
(12, 40, 54),
(12, 41, 55),
(7, 42, 56),
(13, 42, 57),
(7, 43, 58),
(13, 43, 59),
(13, 44, 60),
(9, 44, 61),
(13, 45, 62),
(9, 45, 63),
(13, 46, 64),
(9, 46, 65),
(1, 47, 66),
(9, 47, 67),
(1, 48, 68),
(9, 48, 69),
(1, 49, 70),
(13, 49, 71),
(13, 50, 72),
(1, 50, 73),
(4, 51, 74),
(4, 52, 75),
(12, 53, 76),
(12, 54, 77),
(17, 55, 78),
(17, 56, 79),
(5, 57, 80),
(5, 58, 81),
(6, 59, 82),
(6, 60, 83),
(17, 61, 84),
(17, 62, 85),
(17, 63, 86),
(5, 63, 87),
(14, 64, 88),
(14, 65, 89),
(14, 66, 90),
(5, 67, 91),
(5, 68, 92),
(5, 69, 93),
(9, 70, 94),
(13, 70, 95),
(9, 71, 96),
(13, 71, 97),
(9, 72, 98),
(13, 72, 99),
(17, 73, 100),
(13, 73, 101),
(13, 74, 102),
(17, 74, 103),
(10, 75, 104),
(15, 75, 105),
(10, 76, 106),
(15, 76, 107),
(10, 77, 108),
(15, 77, 109),
(6, 78, 110),
(6, 79, 111),
(14, 80, 112),
(17, 80, 113),
(14, 81, 114),
(17, 81, 115),
(4, 82, 116),
(4, 83, 117),
(7, 84, 118),
(12, 84, 119),
(7, 85, 120),
(12, 85, 121),
(7, 86, 122),
(12, 86, 123),
(17, 87, 124),
(17, 88, 125),
(11, 88, 126),
(13, 89, 127),
(13, 90, 128),
(17, 91, 129),
(17, 92, 130),
(11, 92, 131),
(8, 93, 132),
(13, 93, 133),
(8, 94, 134),
(13, 94, 135),
(8, 95, 136),
(13, 95, 137),
(15, 96, 138),
(10, 96, 139),
(14, 97, 140),
(14, 98, 141),
(17, 99, 142),
(17, 100, 143),
(4, 101, 144),
(4, 101, 145),
(9, 103, 146),
(14, 103, 147),
(9, 104, 148),
(14, 104, 149),
(4, 105, 150),
(4, 106, 151),
(5, 107, 152),
(5, 108, 153),
(12, 109, 154),
(13, 110, 155),
(13, 111, 156),
(10, 112, 157),
(15, 112, 158),
(10, 113, 159),
(15, 113, 160),
(12, 114, 161),
(9, 115, 162),
(12, 116, 163),
(17, 117, 164),
(17, 118, 165),
(17, 119, 166),
(17, 120, 167),
(17, 121, 168),
(14, 122, 169),
(17, 122, 170),
(14, 123, 171),
(1, 124, 172),
(7, 124, 173),
(11, 125, 174),
(14, 125, 175),
(4, 126, 176),
(6, 127, 177),
(1, 128, 178),
(12, 129, 179),
(17, 130, 180),
(17, 131, 181),
(7, 131, 182),
(11, 132, 183),
(17, 132, 184),
(12, 133, 185),
(12, 134, 186),
(17, 135, 187),
(4, 136, 188),
(6, 137, 189),
(12, 138, 190),
(15, 139, 191),
(17, 139, 192),
(17, 140, 193),
(15, 140, 194),
(15, 141, 195),
(17, 141, 196),
(15, 142, 197),
(17, 142, 198),
(15, 143, 199),
(7, 143, 200),
(7, 144, 201),
(11, 144, 202),
(12, 152, 203),
(11, 145, 204),
(7, 145, 205),
(4, 145, 206),
(7, 146, 207),
(6, 146, 208),
(3, 147, 209),
(3, 148, 210),
(3, 149, 211),
(7, 149, 212),
(14, 150, 213),
(14, 151, 214);

-- --------------------------------------------------------

--
-- Table structure for table `pokemon_users`
--

CREATE TABLE `pokemon_users` (
  `pokemon_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

CREATE TABLE `types` (
  `name` varchar(255) NOT NULL,
  `weakness` varchar(255) NOT NULL,
  `strength` varchar(255) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`name`, `weakness`, `strength`, `id`) VALUES
('Bug', 'Fire, Flying, Rock', 'Grass, Psychic', 1),
('Dragon', 'Dragon, Ice', 'Dragon', 3),
('Electric', 'Ground', 'Flying, Water', 4),
('Fighting', 'Flying, Psychic', ' Ice, Normal, Rock', 5),
('Fire', 'Ground, Rock, Water', 'Bug, Grass, Ice', 6),
('Flying', 'Electric, Ice, Rock', 'Bug, Grass, Fighting', 7),
('Ghost', 'Ghost', 'Ghost, Psychic', 8),
('Grass', 'Bug, Fire, Flying, Ice, Poison', 'Ground, Rock, Water', 9),
('Ground', 'Grass, Ice, Water', 'Electric, Fire, Poison, Rock', 10),
('Ice', 'Fighting, Fire, Rock, Steel', 'Dragon, Flying, Grass, Ground', 11),
('Normal', 'Fighting', 'N/A', 12),
('Poison', 'Ground, Psychic', 'Grass', 13),
('Psychic', 'Bug,  Ghost', 'Fighting, Poison', 14),
('Rock', 'Fighting, Grass, Ground, Steel, Water', 'Bug, Fire, Flying, Ice', 15),
('Water', 'Electric, Ground, Rock', 'Fire, Ground Rock', 17);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `pokemon_types`
--
ALTER TABLE `pokemon_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pokemon_users`
--
ALTER TABLE `pokemon_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pokemon`
--
ALTER TABLE `pokemon`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;
--
-- AUTO_INCREMENT for table `pokemon_types`
--
ALTER TABLE `pokemon_types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=215;
--
-- AUTO_INCREMENT for table `pokemon_users`
--
ALTER TABLE `pokemon_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
