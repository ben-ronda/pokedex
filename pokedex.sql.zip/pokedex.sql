--
-- Database: `pokedex`
--
CREATE DATABASE IF NOT EXISTS `pokedex` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `pokedex`;

-- --------------------------------------------------------

--
-- Table structure for table `pokemon`
--

CREATE TABLE `pokemon` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `height_feet` int(11) DEFAULT NULL,
  `height_inches` int(11) DEFAULT NULL,
  `weight` decimal(4,1) DEFAULT NULL,
  `dex_number` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pokemon`
--

INSERT INTO `pokemon` (`id`, `name`, `height_feet`, `height_inches`, `weight`, `dex_number`) VALUES
(2, 'Bulbasaur', 2, 4, '15.2', '001'),
(3, 'Ivysaur', 3, 3, '28.7', '002'),
(4, 'Venusaur', 6, 7, '220.5', '003'),
(5, 'Charmander', 2, 0, '18.7', '004'),
(6, 'Charmeleon', 3, 7, '41.9', '005'),
(7, 'Charizard', 5, 7, '199.5', '006'),
(8, 'Squirtle', 1, 8, '19.8', '007'),
(9, 'Wartortle', 3, 3, '49.6', '008'),
(10, 'Blastoise', 5, 3, '188.5', '009'),
(11, 'Caterpie', 1, 0, '6.4', '010'),
(12, 'Metapod', 2, 4, '21.8', '011'),
(13, 'Butterfree', 3, 7, '70.5', '012'),
(14, 'Weedle', 1, 0, '7.1', '013'),
(15, 'Kakuna', 2, 0, '22.0', '014'),
(16, 'Beedrill', 3, 3, '65.0', '015'),
(17, 'Pidgey', 1, 0, '4.0', '016'),
(18, 'Pidgeotto', 3, 7, '66.1', '017'),
(19, 'Pidgeot', 4, 11, '87.1', '018'),
(20, 'Rattata', 1, 0, '7.7', '019'),
(21, 'Raticate', 2, 4, '40.8', '020'),
(22, 'Spearow', 1, 0, '4.4', '021'),
(23, 'Fearow', 3, 11, '83.8', '022'),
(24, 'Ekans', 6, 7, '15.2', '023'),
(25, 'Arbok', 11, 6, '143.3', '024'),
(26, 'Pikachu', 1, 4, '13.2', '025'),
(27, 'Raichu', 2, 7, '66.1', '026'),
(28, 'Sandshrew', 2, 0, '26.5', '027'),
(29, 'Sandslash', 3, 3, '65.0', '028'),
(30, 'Nidoran', 1, 4, '15.4', '029'),
(31, 'Nidorina', 2, 7, '44.1', '030'),
(32, 'Nidoqueen', 4, 3, '132.3', '031'),
(33, 'Nidoran (male)', 1, 8, '19.8', '032'),
(34, 'Nidorino', 2, 11, '43.0', '033'),
(35, 'Nidoking', 4, 7, '136.7', '034'),
(36, 'Clefairy', 2, 0, '16.5', '035'),
(37, 'Clefable', 4, 3, '88.2', '036'),
(38, 'Vulpix', 2, 0, '21.8', '037'),
(39, 'Ninetales', 3, 7, '43.9', '038'),
(40, 'Jigglypuff', 1, 8, '12.1', '039'),
(41, 'Wigglytuff', 3, 3, '26.5', '040'),
(42, 'Zubat', 2, 7, '16.5', '041'),
(43, 'Golbat', 5, 3, '121.3', '042'),
(44, 'Oddish', 1, 8, '11.9', '043'),
(45, 'Gloom', 2, 7, '19.0', '044'),
(46, 'Vileplume', 3, 11, '41.0', '045'),
(47, 'Paras', 1, 0, '11.9', '046'),
(48, 'Parasect', 3, 3, '65.0', '047'),
(49, 'Venonat', 3, 3, '66.1', '048'),
(50, 'Venomoth', 4, 11, '27.6', '049'),
(51, 'Diglett', 0, 8, '1.8', '050'),
(52, 'Dugtrio', 2, 4, '73.4', '051'),
(53, 'Meowth', 1, 4, '9.3', '052'),
(54, 'Persian', 3, 3, '70.5', '053'),
(55, 'Psyduck', 2, 7, '43.2', '054'),
(56, 'Golduck', 5, 7, '168.9', '055'),
(57, 'Mankey', 1, 8, '61.7', '056'),
(58, 'Primeape', 3, 3, '70.5', '057'),
(59, 'Growlithe', 2, 4, '41.9', '058'),
(60, 'Arcanine', 6, 3, '341.7', '059'),
(61, 'Poliwag', 2, 0, '27.3', '060'),
(62, 'Poliwhirl', 3, 3, '44.1', '061'),
(63, 'Poliwrath', 4, 3, '119.0', '062'),
(64, 'Abra', 2, 11, '43.0', '063'),
(65, 'Kadabra', 4, 3, '124.6', '064'),
(66, 'Alakazam', 4, 11, '105.8', '065'),
(67, 'Machop', 2, 7, '43.0', '066'),
(68, 'Machoke', 2, 7, '155.4', '067'),
(69, 'Machamp', 5, 3, '286.6', '068'),
(70, 'Bellesprout', 2, 4, '8.8', '069'),
(71, 'Weepinbell', 3, 3, '14.1', '070'),
(72, 'Victreebel', 5, 7, '34.2', '071'),
(73, 'Tentacool', 2, 11, '100.3', '072'),
(74, 'Tentacruel', 5, 3, '121.3', '073'),
(75, 'Geodude', 1, 4, '44.1', '074'),
(76, 'Graveler', 3, 3, '231.5', '075'),
(77, 'Golem', 4, 7, '661.4', '076'),
(78, 'Ponyta', 3, 3, '66.1', '077'),
(79, 'Rapidash', 5, 7, '209.4', '078'),
(80, 'Slowpoke', 3, 11, '79.4', '079'),
(81, 'Slowbro', 5, 3, '173.1', '080'),
(82, 'Magnemite', 1, 0, '13.2', '081'),
(83, 'Magneton', 3, 3, '132.3', '082'),
(84, 'Farfetch''d', 2, 7, '33.1', '083'),
(85, 'Doduo', 4, 7, '86.4', '084'),
(86, 'Dodrio', 5, 11, '187.8', '085'),
(87, 'Seel', 3, 7, '198.4', '086'),
(88, 'Dewgong', 5, 7, '264.6', '087'),
(89, 'Grimer', 2, 11, '66.1', '088'),
(90, 'Muk', 3, 11, '66.1', '089'),
(91, 'Shellder', 1, 0, '8.8', '090'),
(92, 'Cloyster', 4, 11, '292.1', '091'),
(93, 'Gastly', 4, 3, '0.2', '092'),
(94, 'Haunter', 5, 3, '0.2', '093'),
(95, 'Gengar', 4, 11, '89.3', '094'),
(96, 'Onix', 28, 10, '463.0', '095'),
(97, 'Drowzee', 3, 3, '71.4', '096'),
(98, 'Hypno', 5, 3, '166.7', '097'),
(99, 'Krabby', 1, 4, '14.3', '098'),
(100, 'Kingler', 4, 3, '132.3', '099'),
(101, 'Voltorb', 1, 8, '22.9', '100'),
(102, 'Electrode', 3, 11, '146.8', '101'),
(103, 'Exeggcute', 1, 4, '5.5', '102'),
(104, 'Exeggutor', 6, 7, '264.6', '103'),
(105, 'Cubone', 1, 4, '14.3', '104'),
(106, 'Marowak', 3, 3, '99.2', '105'),
(107, 'Hitmonlee', 4, 11, '109.8', '106'),
(108, 'Hitmonchan', 4, 7, '110.7', '107'),
(109, 'Lickitung', 3, 11, '144.4', '108'),
(110, 'Koffing', 2, 0, '2.2', '109'),
(111, 'Weezing', 3, 11, '20.9', '110'),
(112, 'Rhyhorn', 3, 3, '253.5', '111'),
(113, 'Rhydon', 6, 3, '264.6', '112'),
(114, 'Chansey', 3, 7, '76.3', '113'),
(115, 'Tangela', 3, 3, '77.2', '114'),
(116, 'Kangaskhan', 7, 3, '176.4', '115'),
(117, 'Horsea', 1, 4, '17.6', '116'),
(118, 'Seadra', 3, 11, '55.1', '117'),
(119, 'Goldeen', 2, 0, '33.1', '118'),
(120, 'Seaking', 4, 3, '86.0', '119'),
(121, 'Staryu', 2, 7, '76.1', '120'),
(122, 'Starmie', 3, 7, '176.4', '121'),
(123, 'Mr.Mime', 4, 3, '120.1', '122'),
(124, 'Scyther', 4, 11, '123.5', '123'),
(125, 'Jynx', 4, 7, '89.5', '124'),
(126, 'Electabuzz', 3, 7, '66.1', '125');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pokemon`
--
ALTER TABLE `pokemon`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pokemon`
--
ALTER TABLE `pokemon`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
